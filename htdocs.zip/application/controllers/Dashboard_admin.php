<?php

    class Dashboard_admin extends CI_Controller {
        public function index(){
            $this->load->view('/admin_index/index');
        } 
    }

