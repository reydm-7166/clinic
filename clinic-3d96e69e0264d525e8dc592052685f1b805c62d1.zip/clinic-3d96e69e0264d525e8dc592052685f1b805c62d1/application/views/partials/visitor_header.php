<div class="parallax">
    <div class="topnav">
      <div class="topnav-logo"><a href="/"><img src="../../../user_guide/_images/Logo.png" width='250' height='40'></a></div>
      <ul>
        <li><a class="current" href="/">Home</a></li>
        <li><a href="about">About Us</a></li>
        <li><a href="services">Services</a></li>
        <li><a href="contact">Contact</a></li>
        <li><a href="faqs">FAQs</a></li>
        <li><a href="signup">Register</a></li>
        <li><a href="signin">Login</a></li>
      </ul>
    </div>
  
    <div class="icons">
      <a href="#" class="fa fa-facebook"></a>
      <a href="#" class="fa fa-youtube"></a>
      <a href="#" class="fa fa-google"></a>
    </div>
  </div>