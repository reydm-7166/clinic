<div class="footer">
    <footer class="site-footer">
      <div class="container">
        <div class="row">
          <div class="col-sm-1 col-md-6">
            <h6>Get in Touch</h6>
          </div>

          <div class="col-sm-1 col-md-5">
            <h6>Quick Links</h6>
          </div>
        </div>

        <div class="row">
          <div class="col-sm-1 col-md-1">
            <i class="fa fa-envelope-o"></i>
            <i class="fa fa-phone mt-5 d-block"></i><br><br>
            <i class="fa fa-map-marker "></i>
          </div>

          <div class="col-xs-5 col-md-5 pt-3">
            <p>wellnessfirst@gmail.com</p><br>
            <p>Front Desk <a href="tel: +63 995 714 3195">+63 995 714 3195</a></p>
				    <p class="pb-3">Consultant <a href="tel: +63 936 951 5888">+63 936 951 5888</a></p>
            
            <p>Unit 521 One Oasis Hub B, Ortigas Ave. Ext. Pasig City, Philippines</p>

            </div>
          <div class="col-xs-6 col-md-3">
            <ul class="footer-links">
              <li><a href="/">Home</a></li>
              <li><a href="service">Services</a></li>
              <li><a href="">FAQs</a></li>
              
            </ul>
          </div>
        </div>
        <hr>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-md-8 col-sm-6 col-xs-12">
            <p class="copyright-text">Copyright &copy; 2020 All Rights Reserved by 
         Wellness First Naturopathic</a>.
            </p>
          </div>
          
         
        </div>
      </div>
    </footer>
  </div>