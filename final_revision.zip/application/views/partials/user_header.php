<div class="parallax">
    <div class="topnav">
      <div class="topnav-logo"><a href="/"><img src="../../../user_guide/_images/Logo.png" width='250' height='40'></a></div>
      <ul>
        <li><a href="/">Home</a></li>
        <li><a href="services">Services</a></li>
        <li><a href="faqs">FAQs</a></li>
        <li><a href="signin">Book A Schedule</a></li>
      </ul>
    </div>
  </div>