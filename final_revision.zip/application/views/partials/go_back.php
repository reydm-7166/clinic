<button type="button" id="Back" class="btn btn-danger" onClick= "history.back()">Back</button>
<style>
    #Back {
        position: absolute;
        top: 10rem;
        left: 31rem;
    }
</style>